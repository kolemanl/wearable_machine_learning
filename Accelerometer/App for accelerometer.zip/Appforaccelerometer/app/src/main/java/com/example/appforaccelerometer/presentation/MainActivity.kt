/* While this template provides a good starting point for using Wear Compose, you can always
 * take a look at https://github.com/android/wear-os-samples/tree/main/ComposeStarter and
 * https://github.com/android/wear-os-samples/tree/main/ComposeAdvanced to find the most up to date
 * changes to the libraries and their usages.
 */

package com.example.appforaccelerometer.presentation

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import com.example.appforaccelerometer.R
import com.example.appforaccelerometer.presentation.theme.AppForAccelerometerTheme
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Timer
import kotlin.concurrent.timerTask


class MainActivity : ComponentActivity() {

    private lateinit var sensorManager: SensorManager
    private lateinit var accelerometer: Sensor
    private lateinit var sensorEventListener: SensorEventListener
    private var isCollectingData = false
    private var timer: Timer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val dataInterval: Long = 50
    private val accelerometerData = FloatArray(3)
    private var fileCounter = 0
    private var startTime: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                1
            )
        }
    }

    fun startDataCollection(view: View) {
        isCollectingData = true
        val startButton = findViewById<Button>(R.id.start_button)
        val stopButton = findViewById<Button>(R.id.stop_button)
        val fileCounterText = findViewById<TextView>(R.id.file_counter_text)

        startButton.visibility = View.GONE
        stopButton.visibility = View.VISIBLE

        fileCounter+=1
        fileCounterText.text = "File Counter: $fileCounter"

        startTime = System.currentTimeMillis()

        try {
            val file = File(getExternalFilesDir(null), "accelerometer_data_$fileCounter.csv")
            val fos = FileOutputStream(file, true) // Append mode
            val writer = fos.bufferedWriter()
            writer.write("Timestamp,Elapsed Time(s),X,Y,Z\n")
            writer.close()
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        timer = Timer()
        timer?.scheduleAtFixedRate(timerTask {
            handler.post {
                if (isCollectingData) {
                    writeDataToCsv(accelerometerData[0], accelerometerData[1], accelerometerData[2])
                }
            }
        }, 0, dataInterval)

        sensorEventListener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (isCollectingData) {
                    accelerometerData[0] = event.values[0]
                    accelerometerData[1] = event.values[1]
                    accelerometerData[2] = event.values[2]
                }
            }

            override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
                // Not used in this example
            }
        }
        sensorManager.registerListener(
            sensorEventListener,
            accelerometer,
            SensorManager.SENSOR_DELAY_NORMAL
        )
    }

    fun stopDataCollection(view: View) {
        isCollectingData = false
        val startButton = findViewById<Button>(R.id.start_button)
        val stopButton = findViewById<Button>(R.id.stop_button)
        startButton.visibility = View.VISIBLE
        stopButton.visibility = View.GONE
        sensorManager.unregisterListener(sensorEventListener)
        timer?.cancel()

//        val file = File(getExternalFilesDir(null), "accelerometer_data.xml")
//        val fos = FileOutputStream(file, true) // Append mode
//        val data = "</accelerometer_data>"
//        fos.write(data.toByteArray())
//        fos.close()
    }

    private fun writeDataToCsv(x: Float, y: Float, z: Float) {
        try {
            val file = File(getExternalFilesDir(null), "accelerometer_data_$fileCounter.csv")
            val fos = FileOutputStream(file, true) // Append mode
            val writer = fos.bufferedWriter()

            val elapsedTime = (System.currentTimeMillis() - startTime) / 1000.0
            val timestamp = System.currentTimeMillis()
            val data = "$timestamp,$elapsedTime,$x,$y,$z\n"
            writer.write(data)
            writer.close()
            fos.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }


    }

    @Composable
    fun WearApp(greetingName: String) {
        AppForAccelerometerTheme {
            /* If you have enough items in your list, use [ScalingLazyColumn] which is an optimized
         * version of LazyColumn for wear devices with some added features. For more information,
         * see d.android.com/wear/compose.
         */
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colors.background),
                verticalArrangement = Arrangement.Center
            ) {
                Greeting(greetingName = greetingName)
            }
        }
    }

    @Composable
    fun Greeting(greetingName: String) {
        Text(
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            color = MaterialTheme.colors.primary,
            text = stringResource(R.string.hello_world, greetingName)
        )
    }

    @Preview(device = Devices.WEAR_OS_SMALL_ROUND, showSystemUi = true)
    @Composable
    fun DefaultPreview() {
        WearApp("Preview Android")
    }
