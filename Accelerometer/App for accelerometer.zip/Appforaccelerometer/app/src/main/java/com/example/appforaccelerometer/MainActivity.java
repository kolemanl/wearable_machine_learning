package com.example.appforaccelerometer;

import android.app.Activity;

public class MainActivity extends Activity {
}
